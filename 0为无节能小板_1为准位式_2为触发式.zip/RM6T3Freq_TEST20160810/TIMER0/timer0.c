#include "../SRC/MB95770.h"
#include "../INC/untype_def.h"
#include "../DISPLAY/display.h"
#include "../ENER_SAVING/ener_saving.h"
#include "../UART/uart.h"
#include "../BUZZ/buzz.h"
#include "timer0.h"

//ENER_SAVING     ener_sav;
TIMER_USRRAM    g_tTime;
Bit_FLAGSTR     bitFlag1;
Bit_FLAGSTR     bitFlag2;
BUZZER_RAM      buzzer_ram;
uint8 enerSav_keyStatus;

/****************************************************************************
name: Timr0_Init
funtion:��ʼ����ʱ��
���϶�ʱ��:1)���ݴ����� 	*2 channels (T00DR/T01DR), (T10DR/T11DR)
	   2)״̬���ƼĴ���	0��2 channels (T00CR0/T01CR0), (T10CR0/T11CR0)
	   3)״̬���ƼĴ���	1 �� 2 channels (T00CR1/T01CR1), (T10CR1/T11CR1)
	   4)ģʽ���ƼĴ���	(TMCR0), (TMCR1)
****************************************************************************/
void Timr0_Init(void)
{
        T00CR0 = 0x81;		//;Interval timer (continuous mode)..1 X MCLK.
	  	T00CR1 = 0x00;		//;������ʱ��.��ʼΪ��.δ���ж�.��ʱ����ֹ���.
	  	TMCR0 = 0x30;		//;��ʱ��0��1�������.ѡ���ڲ�ʱ��.16λģʽ.
	  	T01DR = 0x0F;       // 31;		//250us..
	  	T00DR = 0xA0;       //64;
	  	T00CR1 = 0xA0;		////;..������ʱ������..���λ=0ʱ.�жϲ����..

        Time0Val_Init();
} 


void Time0Val_Init(void)
{
    g_tTime.Cnt_500us = 0;
    g_tTime.Cnt_1ms = 0;
    g_tTime.Cnt_2ms = 2;
    g_tTime.Cnt_10ms = 10;
    g_tTime.Cnt_20ms = 2;
    g_tTime.Cnt_25ms = 25;
    g_tTime.Cnt_50ms = 5;
    g_tTime.Cnt_100ms = 100;
    g_tTime.Cnt_300ms = 3;
    g_tTime.Cnt_500ms = 5;

    TimeCnt250Us_bit = 0;
    TimeCnt500Us_bit = 0;
    TimeCnt1Ms_bit = 0;
    TimeCnt10Ms_bit = 0; 
    TimeCnt25Ms_bit = 0;
    TimeCnt50Ms_bit = 0;
    TimeCnt100Ms_bit = 0;
    TimeCnt300Ms_bit = 0;
    enerSav_keyStatus = 0;  //Ĭ��Ϊ��������С��
    Cnt5sFlag = 1;
}


__interrupt void timer00_inter (void)
{
    if(g_tTime.Cnt_500us)                    //500US
    {
        g_tTime.Cnt_500us = 0;

        if(g_tTime.Cnt_1ms)                  // 1MS
		{
            g_tTime.Cnt_1ms = 0;
            TimeCnt1Ms_bit = 1;

            Buzzer_Process();   //buzz
            LedDisplay();       //

            g_tTime.Cnt_25ms--;
    	    if(NULL == g_tTime.Cnt_25ms)     //25MS
    	    {
                g_tTime.Cnt_25ms = 25;
                P_RPM = ~P_RPM;     //
    	    }

            g_tTime.Cnt_10ms--;
            if(NULL == g_tTime.Cnt_10ms)    //10MS
            {
                TimeCnt10Ms_bit = 1;
                g_tTime.Cnt_10ms = 10;
                
                buzzer_ram.Buzzer10ms_bit = 1;	//Buzzer_Process 10msִ��һ��	

                if((Cnt5sFlag == 1) & (P_MODE_CS == 0))  //5���ڼ��ener_saving����
                {
                    delay_time(10);
                    if(P_MODE_CS == 0)
                    {
                        kFlag = 1;
                        while(kFlag)
                        {
                            if(P_MODE_CS == 1)
                            {
                                kFlag = 0;
                                enerSav_keyStatus++;

                                if(enerSav_keyStatus > 2)
                                {
                                    enerSav_keyStatus = 0;
                                }
                            }
                        }
                    }
                }
            }

            g_tTime.Cnt_100ms--;
    	    if(NULL == g_tTime.Cnt_100ms)     //100MS
    	    {
                g_tTime.Cnt_100ms = 100;
                TimeCnt100Ms_bit = 1;

                if(ener_sav.timeCnt < 51)
                {
                    ener_sav.timeCnt ++;
                }
                else if(Cnt5sFlag == 1)
                {
                    Cnt5sFlag = 0;
                }
           	}
        }
       	else
		{
            g_tTime.Cnt_1ms ++;
       	}

        if (buzzer_ram.BeepOn_bit)
        {
			P_BUZZ_CTL = ~P_BUZZ_CTL;
        }
		else
		{
			P_BUZZ_CTL =0;
		}

    }
    else
    {
        g_tTime.Cnt_500us++;
    }

    T00CR1_IF = 0;//���־λ
}






