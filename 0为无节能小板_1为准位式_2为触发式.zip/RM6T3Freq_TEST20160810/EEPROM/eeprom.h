#ifndef __EEPROM_h__
#define __EEPROM_h__

#define    P_EE_CS   PDRC_PC1
#define    P_EE_SK   PDRC_PC0
#define    P_EE_DI   PDRB_PB1
#define    P_EE_DO_IN   PDRB_PB0
#define    D_EE_CS   DDRC_PC1
#define    D_EE_SK   DDRC_PC0
#define    D_EE_DI   DDRB_PB1
#define    D_EE_DO_IN   DDRB_PB0

#define    P_BUZZ_CTL  PDRE_PE1
#define    D_BUZZ_CTL  DDRE_PE1

/*eeprom�ڴ����
#define		EADR_jizhong_1      135//����
#define		EADR_jizhong_2      136 //����
#define		EADR_version        137//�汾
#define		EADR_YearsMonth     138//���� ��/��
#define		EADR_Date           139  //�� / 0 A/B/C/D��...
*/

extern void eeprom_Init(void);//��ʼ��eeprom
extern void Write_EEPROM(uint8 eeaddr,uint16 eedata);
extern int Read_EEPROM(uint8 addr );  
extern void ease_alleeprom(void);//���eeprom
extern void buzz(uint16 time);
extern void delay_time (uint16 data);

#endif

