#include "../SRC/mb95770.h"
#include "../INC/untype_def.h"
#include "Eeprom.h"

/*******************************************************************/
void delay_time (uint16 data)
{
    uint16 i;
    for(i = 0;i<data;i++)
    {
        __wait_nop();
    }
}

/**********************************************************************
name:	eeprom_Init
function:	initial eeprom ..it can write..
**********************************************************************/

void eeprom_Init(void)
{
	uint8 i,q6;
	uint16  AL16,data = 0;

    P_EE_CS = 0;
	D_EE_CS = 1;
	P_EE_SK = 0;
	D_EE_SK = 1;
	P_EE_DI = 0;
	D_EE_DI = 1;
	P_EE_DO_IN = 1;
	D_EE_DO_IN = 1;
    D_BUZZ_CTL = IO_OUTPUT; //BUZZ    
    P_BUZZ_CTL = IO_OUTPUT; //  
    P_BUZZ_CTL = IO_INPUT; //  

    
	P_EE_CS = 0;
  	AL16 = 0XC0; 
	AL16 = AL16+0x400;	//0b100,11000000;   //inst & addr
	AL16 = AL16<<5;
	P_EE_CS = 1;
	P_EE_SK = 0; 	
	delay_time(20); 
	P_EE_SK = 0; 	
	for (q6 = 0; q6 < 11; q6++)           //writing
    {
		if (AL16&0x8000)
		{ 
			P_EE_DI = 1; 	   
		} 
		else
		{
			P_EE_DI = 0; 	   
		} 
		delay_time(20);  
		P_EE_SK = 1; 		
		delay_time(20);  
		P_EE_SK = 0; 		
		delay_time(20);  
		AL16 = AL16<<1;		 
	}
	delay_time(20);   	
	P_EE_CS = 0;
}

void buzz(uint16 time)
{
   // P_POW_Ctrl = IO_OUTPUT;

    P_BUZZ_CTL = IO_OUTPUT;
    delay_time(time);
    P_BUZZ_CTL = IO_INPUT; 
    delay_time(time);
    P_BUZZ_CTL = IO_OUTPUT;
    delay_time(time);
    P_BUZZ_CTL = IO_INPUT; 
}

/*--------------------------------------------------------------*/
/*Function: Write_EEPROM 
/*--------------------------------------------------------------*/
void Write_EEPROM(uint8 eeaddr,uint16 eedata)  
{
	uint16 AL16;
	uint8 q6,i;
	P_EE_CS = 0;
	AL16 = eeaddr;
    AL16 = AL16+0x500;						//0 b101 0000 0000;  //inst & addr
    AL16 = AL16<<5;
    P_EE_CS = 1; 
	P_EE_SK=0; 
	delay_time(5);   
    for(q6=0;q6<11;q6++)                    //writing
    {
		if(AL16&0x8000)
			P_EE_DI= 1; 	   
		else
			P_EE_DI= 0;
			
		delay_time(5); 	
		P_EE_SK=1;  
	    delay_time(5);  
		P_EE_SK=0;  		
		delay_time(5);  
		AL16 = AL16<<1;		 
    }
    AL16=eedata;
	for(q6=0;q6<16;q6++)           // && q1<25) //transfer 16 bits data to eeprom
    {	
		if(AL16&0x1)
		{ 
			P_EE_DI = 1; 	   
		} 
		else
		{
			P_EE_DI = 0; 	   
		} 
		P_EE_SK=1; 	
		delay_time(5); 
		P_EE_SK=0; 		
		delay_time(5); 	
		AL16 = AL16>>1;		 
    }
	P_EE_CS = 0;  
	delay_time(5);
	P_EE_CS = 1;
	delay_time(5);	
	for (AL16=0;AL16<=1000;AL16++)	
	{
		if (P_EE_DO_IN ==1)
		{
			break;
		}	 
	}
	P_EE_CS = 0; 
	delay_time(5); 
}

/*--------------------------------------------------------------*/
/*Function: Read_EEPROM        		              			*/
/*INPUT: 
/*--------------------------------------------------------------*/

int Read_EEPROM(uint8 addr )  
{
	uint8 i,q6;
	uint16 AL16,data=0;
	 
	P_EE_CS=0;
	AL16 = addr;
    AL16 = AL16+0x600;	//0b11000000000;   //inst & addr
    AL16 = AL16<<5;
	P_EE_CS=1;
	P_EE_SK=0; 
	delay_time(30); 
	for(q6=0;q6<11;q6++)                    //writing
    {
		if(AL16&0x8000)
		{ 
			P_EE_DI= 1; 	   
		} 
		else
		{
			P_EE_DI= 0; 	   
		} 
		delay_time(10);  
		P_EE_SK=1; 		
		delay_time(10);  
		P_EE_SK=0; 		
		AL16 = AL16<<1;	
		delay_time(10);  		
	}
	 
	data = 0;
	for(i=0;i<16;i++)
	{	 
	    data=data>>1;
		P_EE_SK=1; 	
		delay_time(10);  
	    if(P_EE_DO_IN!=0)
		{
			data = data+0x8000;		
	   	}
		P_EE_SK=0; 	
	    delay_time(10);
	}
	
	P_EE_CS = 0; 
	delay_time(50);
	return(data);
    
}
 
/************************************************************
name:	ease_alleeprom
function:
/************************************************************/ 
void ease_alleeprom(void)
{	
	uint8 i,q6;
	uint16 AL16,data=0;

	P_EE_CS=0;
    AL16 = 0X80; 
    AL16 = AL16+0x400;	//0b100,10000000;   //inst & addr
    AL16 = AL16<<5;
	P_EE_CS=1;
	P_EE_SK=0; 	
	 delay_time(50); 
	 P_EE_SK=0; 	
	for(q6=0;q6<11;q6++)                    //writing
    { 
		if(AL16&0x8000)
		{ 
			P_EE_DI= 1; 	   
		} 
		else
		{
			P_EE_DI= 0; 	   
		} 
		delay_time(50);  
		P_EE_SK=1; 		
		delay_time(50);  
		P_EE_SK=0; 		
		delay_time(50);  
		AL16 = AL16<<1;		 
	}
	delay_time(50);   	
	P_EE_CS=0;  
	delay_time(50);
	P_EE_CS = 1;
	delay_time(50);	
	for (AL16=0;AL16<=1000;AL16++)	
	{
		if (P_EE_DO_IN ==1)
		{
			break;
		}	 
	}
	P_EE_CS = 0; 
	delay_time(50);
} 

/*
void Save_Date_Time()
{
	 Write_EEPROM(98,sysjizhong_data[0]);
     Write_EEPROM(100,sysjizhong_data[1]);
	 Write_EEPROM(102,sysjizhong_data[2]);
	 Write_EEPROM(101,sysjizhong_data[3]);
	 Write_EEPROM(109,sysjizhong_data[4]);
}


uint16 c[5];

void Read_Date_Time()
{
    c[0]=Read_EEPROM(98);
    c[1]=Read_EEPROM(100);
    c[2]=Read_EEPROM(102);
    c[3]=Read_EEPROM(101);
    c[4]=Read_EEPROM(109);
    
}*/
