#include "../ENER_SAVING/ener_saving.h"
#include "../SRC/mb95770.h"
#include "../INC/untype_def.h"
#include "../UART/uart.h"
#include "../BUZZ/buzz.h"
#include "display.h"

INT8U COM_DisBuf[COMMAX];
INT8U SEG_DisBuf[SEGMAX];
INT8U LED_DisBuf[LEDMAX];

LED_DISP led_disp;

/**********************************************************/
/* num0-->num9  _A �__F  _E  _S  _P  dot   _num0 _num9    */
/*   0-9        10   15  11  13  14  16      17   26      */
const INT8U seg8_display[] = {num0,num1,num2,num3,num4,num5,
       num6,num7,num8,num9,_A,_E,BLANK,_S,_P,_F,dot,_num0,
       _num1,_num2,_num3,_num4,_num5,_num6,_num7,_num8,_num9};

/**********************************************************/
void value_Init(void)
{
    led_disp.CS_Cnt = 5;
    closeDisFlag = 0;
}

/**********************************************************/
void IO_Init(void)
{
    AIDRL   = 0xFF; 
    LCDCE1  = 0x80;

    DDRA    = 0X1F;
    DDR6    = 0XFE;
    DDRE_PE0 =1; 
    
    /*-------------------------------*/
    DDR0_P06 = IO_INPUT;    //safy_in
    D_RPM = IO_OUTPUT;      //RPM     
    P_RPM = IO_OUTPUT;      //        
    D_POW_Ctrl = IO_OUTPUT; //POWER   
    P_POW_Ctrl = IO_OUTPUT; //        
    /*-------------------------------*/
}

/**********************************************************/
void refreshScreen(void) 
{
    PDR6_P61 = SEG_DisBuf[0];
    PDR6_P62 = SEG_DisBuf[1];
    PDR6_P63 = SEG_DisBuf[2];
    PDR6_P64 = SEG_DisBuf[3];
    PDR6_P65 = SEG_DisBuf[4];
    PDR6_P66 = SEG_DisBuf[5];
    PDR6_P67 = SEG_DisBuf[6];
    PDRE_PE0 = SEG_DisBuf[7];
}

void selLed(void)
{
    PDRA_PA0 = COM_DisBuf[0];
    PDRA_PA1 = COM_DisBuf[1];    
    PDRA_PA2 = COM_DisBuf[2];
    PDRA_PA3 = COM_DisBuf[3];
    PDRA_PA4 = COM_DisBuf[4];
}
/******************ɾ��С����ǰ��Ч��0*********************/
void deleInvalid0(void)
{
    if((LED_DisBuf[2] > 16) & ( LED_DisBuf[2] < 27))
    {
        if(!LED_DisBuf[0])
        {
            LED_DisBuf[0] = 12;
            if(!LED_DisBuf[1]) LED_DisBuf[1] = 12;
        }
    }
    else if((LED_DisBuf[1] > 16) & ( LED_DisBuf[1] < 27))
    {
        if(!LED_DisBuf[0]) LED_DisBuf[0] = 12;
    }
}
/**********************************************************/
void allLedOff(void)
{
    INT8U tmp_i;
	for(tmp_i = 0;tmp_i < 8;tmp_i ++)
	{	    
	    SEG_DisBuf[tmp_i] = 1;
        COM_DisBuf[tmp_i] = 0;
	}
    selLed();
    refreshScreen();
}

/******************��ʾinscode��״̬***********************/
void LedBufCalc(INT8U dataLow,INT8U dataHig)
{
    LED_DisBuf[0] = dataLow/16;   
    LED_DisBuf[1] = dataLow%16;
    LED_DisBuf[2] = 12;   //����ʾ
    LED_DisBuf[3] = dataHig%10;
    LED_DisBuf[4] = 12;
}

/******************��ʾESP��Ƶ��***************************/
void LedBufCalc_freq(INT8U freqLow,INT8U freqHig)
{
    INT16U  tmp_i,numValue;
    if(PDR0_P06)
    {
        ESPbuzzCnt=1;
        numValue = ( freqHig << 8 ) + freqLow;
        LED_DisBuf[0] = numValue/1000;
        tmp_i = numValue%1000;
        LED_DisBuf[1] = tmp_i/100 + 17; //��С����
        tmp_i = tmp_i%100;
        LED_DisBuf[2] = tmp_i/10;
        LED_DisBuf[3] = tmp_i%10;
        LED_DisBuf[4] = 12;
    }
 /*   else if(closeDisFlag == 1)
    {
        LED_DisBuf[0] = 12;
        LED_DisBuf[1] = 12;
        LED_DisBuf[2] = 12;   //����ʾ
        LED_DisBuf[3] = 12;
        LED_DisBuf[4] = 12;
    }*/
    else
    {
        if(closeDisFlag == 1)
        {
            LED_DisBuf[0] = 12;
            LED_DisBuf[1] = 12;
            LED_DisBuf[2] = 12;   //����ʾ
            LED_DisBuf[3] = 12;
            LED_DisBuf[4] = 12;
        }
        else
        {
            if(ESPbuzzCnt == 1)
            {
                ESPbuzzCnt = 0;
                Buzzer_3Bz();
            }

            LED_DisBuf[0] = 11;  //��ʾESP
            LED_DisBuf[1] = 13;
            LED_DisBuf[2] = 14;
            LED_DisBuf[3] = 12;
            LED_DisBuf[4] = 12;
        }
    }
}

/*********************����趨****************************/
void IncBufCalc(INT8U dataLow8,INT8U dataHig8)
{
    INT16U valCnt,tmp_i;
    valCnt = (dataLow8 << 8) + dataHig8;
    LED_DisBuf[0] = valCnt/1000;
    tmp_i = valCnt%1000;
    LED_DisBuf[1] = tmp_i/100 + 17; //��С����;
    tmp_i = tmp_i%100;
    LED_DisBuf[2] = tmp_i/10;
    LED_DisBuf[3] = tmp_i%10;
    LED_DisBuf[4] = 12;
}
/*********************************************************/
void EnerSav_DisBuf(INT8U data)
{
    if(TimeCnt100Ms_bit)
    {
        LED_DisBuf[0] = data;   
    }
    else
    {
        LED_DisBuf[0] = 12;
    }
    LED_DisBuf[1] = 12;
    LED_DisBuf[2] = 12;   //����ʾ
    LED_DisBuf[3] = 12;
    LED_DisBuf[4] = 12;
}

/**********************************************************/
/**********************************************************/
void LedDisplay(void)
{
    INT8U tmp_i;
    allLedOff();
    deleInvalid0();

    led_disp.Seg8Data = seg8_display[LED_DisBuf[led_disp.CS_Cnt]];
    COM_DisBuf[led_disp.CS_Cnt] = 1;
    for(tmp_i = 0;tmp_i < 8;tmp_i++)
    { 
        SEG_DisBuf[tmp_i] = ~ led_disp.Seg8Data & BIT0;
        led_disp.Seg8Data = (led_disp.Seg8Data >> 1);
    }
    selLed();
    refreshScreen();
    
    led_disp.CS_Cnt ++;
    if(led_disp.CS_Cnt > 4)
    {
        led_disp.CS_Cnt = 0;
    }
}
