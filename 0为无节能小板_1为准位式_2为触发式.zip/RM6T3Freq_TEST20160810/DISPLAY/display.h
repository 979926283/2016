#include "../INC/untype_def.h"

#ifndef _DISPLAY_H_
#define _DISPLAY_H_

/*****************************************************/
#define P_RPM	IO_PDR0.bit.P00	
#define D_RPM   IO_DDR0.bit.P00
/*****************************************************/

#define COM_CS1 PDRA_PA0
#define COM_CS2 PDRA_PA1
#define COM_CS3 PDRA_PA2
#define COM_CS4 PDRA_PA3
#define COM_CS5 PDRA_PA4

#define SEG_IO1 PDR6_P61
#define SEG_IO2 PDR6_P62
#define SEG_IO3 PDR6_P63
#define SEG_IO4 PDR6_P64
#define SEG_IO5 PDR6_P65
#define SEG_IO6 PDR6_P66
#define SEG_IO7 PDR6_P67
#define SEG_IO8 PDRE_PE0

#define COMMAX 8
#define SEGMAX 8
#define LEDMAX 5

extern INT8U    COM_DisBuf[COMMAX];
extern INT8U    SEG_DisBuf[SEGMAX];
extern INT8U    LED_DisBuf[LEDMAX];


/*----------------------------------------------------*/
#define		_a	    0x01		
#define		_b	    0x02			
#define		_c	    0x04				
#define		_d	    0x08			
#define		_e	    0x10			
#define		_f	    0x20			
#define		_g	    0x40			
#define		dp	    0x80
#define		blank	0

#define		num0	(_a | _c | _e | _g | dp | _b)		 	
#define		num1	(_c | _e)
#define		num2	(_a | _c | _d | dp | _g)	
#define		num3	(_a | _c | _d | _e | _g)
#define		num4	(_b | _d | _c | _e)		
#define		num5	(_a | _b | _d | _e | _g)	
#define		num6	(_a | _b | _d | _e | _g | dp)	
#define		num7	(_a | _c | _e)
#define		num8	(_a | _b | _c | _d | _e | dp | _g)
#define		num9	(_a | _b | _c | _d | _e | _g)
#define     _A      (_a | _b | _c | _d | _e | dp)
#define     _F      (_a | _b | _d | dp)
#define     _E      (_a | _b | _d | _g | dp)
#define     _S      (_a | _b | _d | _e | _g)
#define     _P      (_a | _b | _c | _d | dp)
#define     dot     (_f)
#define		_num0	(_a | _c | _e | _g | dp | _b | _f)		 	
#define		_num1	(_c | _e | _f)
#define		_num2	(_a | _c | _d | dp | _g | _f)	
#define		_num3	(_a | _c | _d | _e | _g | _f)
#define		_num4	(_b | _d | _c | _e | _f)		
#define		_num5	(_a | _b | _d | _e | _g | _f)	
#define		_num6	(_a | _b | _d | _e | _g | dp | _f)	
#define		_num7	(_a | _c | _e | _f)
#define		_num8	(_a | _b | _c | _d | _e | dp | _g | _f)
#define		_num9	(_a | _b | _c | _d | _e | _g | _f)
#define		BLANK	blank


/*----------------------------------------------------*/
typedef struct
{
    INT8U CS_Cnt;
    INT8U Seg8Data;
    INT8U dotDisp;
}LED_DISP;

extern LED_DISP led_disp;

/*----------------------------------------------------*/
extern void value_Init(void);
extern void refreshScreen(void);
extern void selLed(void);
extern void allLedOff(void);
void deleInvalid0(void);
extern void LedBufCalc(INT8U dataLow,INT8U dataHig);
extern void LedBufCalc_freq(INT8U freqLow,INT8U freqHig);
extern void LedDisplay(void);
extern void mode(INT8U dataLow);
extern void IncBufCalc(INT8U dataLow8,INT8U dataHig8);


#endif
