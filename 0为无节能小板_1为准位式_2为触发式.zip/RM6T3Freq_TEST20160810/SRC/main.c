#include "_f2mc8fx.h"
#include "../DISPLAY/display.h"
#include "../ENER_SAVING/ener_saving.h"
#include "../EEPROM/eeprom.h"
#include "../BUZZ/buzz.h"
#include "../UART/uart.h"
#include "../TIMER0/timer0.h"



void main(void)
{
    __DI();
    IO_Init();
    EnerSaving_Init();
    Timr0_Init();
    VfCom_Init();
    converter_UART_SIO_Init();     
    InitIrqLevels();
    eeprom_Init();
    value_Init();
    __EI();
    
    ease_alleeprom();
    allLedOff();
    
    while(1)
    {
        analyzeData();
        EnerSaving_ModeSelect();    //����С��

        if(ener_sav.timeCnt > 50)
        {
            //IncBufCalc(currentAdOne,currentAdTwo);//����
            LedBufCalc_freq(freqLow,freqHig); //��ʾESP��Ƶ��
            //LedBufCalc(insCode,status);     //��ʾinscode��״̬
        }
    }
}






