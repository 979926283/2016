#include "../SRC/MB95770.h"
#include "../INC/untype_def.h"
#include "uart.h"

VF_COM vfCom;
VF_COM_TEST vfComTest;

void writeNoHumanCmd(uint8 num);

void converter_UART_SIO_Init(void)
{    
    D_CTRL_TX = 1;
    D_CTRL_RX = 0;
    VF_RE_D = 1;
   
    P_CTRL_TX = 0;
    P_CTRL_RX = 0;
    VF_RE_P = 0;    

    SMC10 = 0x0C;
    SSR0 = 0;
    SMC20 = 0x5E;

    //ʱ�ӳ�ʼ��
    PSSR0 = 0x06;// 1/4MCLK
    BRSR0 = 0x68;//104      MCLK/[4*(1/4]*104) = 9600bps

    TDR0 = 0;
}

void VfCom_Init(void)
{
    vfCom.newPackage = FALSE;
    vfCom.rxTime = 0;
    vfCom.sendStatus = VF_COM_ST_IDLE;
    vfCom.packetTime = 0;    
}

__interrupt void converter_interrupt (void)
{
    if (SSR0_RDRF)  //�н�������
    {
        receiveData();              
        SSR0_RDRF = 0;        
    }
    if (SSR0_TCPL)  //�������
    {
        if (vfCom.sendStatus == VF_COM_ST_TX)
        {
            if (vfCom.sendIndex < vfCom.sendPacketLen)
            {
                if (SSR0_TCPL)
                {
                    TDR0 = vfCom.sendBuf[vfCom.sendIndex];
                    vfCom.sendIndex++;
                }
            }
           else
            {
                if (SSR0_TCPL)
                {
                    vfCom.sendStatus = VF_COM_ST_WAP;
                    VF_RE_RX;
					VfCom_Init();
                }        
            } 
        }
        SSR0_TCPL = 0; 
    }
    else
    {
        SMC20_RERC = 0; //��������
    }
}

/*------------------------------------------------------------------
������:	calCRC
����:	�������ݰ���CRCֵ��
����: uint8 *pSrcBuf,���ݰ��ĵ�ַ��uint8 len���ݰ��ĳ���
���: crcֵ
-------------------------------------------------------------------*/
uint16 calCRC(uint8 *pSrcBuf,uint8 len)
{
    uint8 i;
    uint16 reg_crc = 0xffff;
    
    while(len--)
    {
        reg_crc^= *pSrcBuf++;        
        for(i = 0;i < 8;i++)
        {
            if(reg_crc & 0x01) reg_crc = (reg_crc>>1)^0xA001;            
            else reg_crc = reg_crc>>1;            
        }
    }

    return reg_crc;
}

/*------------------------------------------------------------------
�����ݴ���ɿ��Է��͵����ݰ�
-------------------------------------------------------------------*/ 
uint8 vvvfComPacket(uint8 *pSrcBuf,uint8 *pResultBuf,uint8 len)
{
    uint16 crc;
    uint8  resultLen;

    crc = calCRC(pSrcBuf+1,len-1);
    pSrcBuf[len] = crc/256;    //CRCУ�����16λ
    pSrcBuf[len+1] = crc%256;  //CRCУ�����16λ
    len += 2;// ����CRC�󣬳�������2��

    pResultBuf[0] = pSrcBuf[0];
    pSrcBuf++;
    pResultBuf++;
    len--;// ȥ����ͷ��һ���ֽں󣬶����ݽ��в�֡�
    resultLen = 1;
    while(len)
    {
        if ((*pSrcBuf & 0xF8) == 0xF0) 
        {
            *pResultBuf = 0xF7;        
            pResultBuf++;
            *pResultBuf = (*pSrcBuf) & 0x07;
            pResultBuf++;
            pSrcBuf++;
            resultLen += 2;
        }
        else
        {
            *pResultBuf = *pSrcBuf;
            pResultBuf++;
            pSrcBuf++;   
            resultLen++;
        }
        
        len--;
    }

    *pResultBuf = 0xF4;//���ϰ�β
    resultLen++;

    return resultLen;
}


/*------------------------------------------------------------------
�Խ��յ������ݽ��зֽ�,�鿴�����Ƿ���ȷ
-------------------------------------------------------------------*/
uint8 vvvfComUnpacket(uint8 *pSrcBuf,uint8 *pResultBuf,uint8 len)
{
    uint8  resultLen;
    uint8  *pResultBufTemp;
    uint16 CRCByReceive;
    uint16 CRCByCal;

    pResultBufTemp = pResultBuf;
    pResultBufTemp[0] = pSrcBuf[0];
    pSrcBuf++;
    pResultBufTemp++;
    len--;// ȥ����ͷ��һ���ֽں󣬶����ݽ��в�֡�
    resultLen = 1;
    while(len)
    {
        if ( (*pSrcBuf) == 0xF7 )
        {
            pSrcBuf++;
            *pResultBufTemp = 0xF0 + (*pSrcBuf);
            pResultBufTemp++;
            pSrcBuf++;  
            resultLen++;
            len -= 2;
        }
        else
        {
            *pResultBufTemp = *pSrcBuf;
            pResultBufTemp++;
            pSrcBuf++;  
            
            resultLen++;
            len--;
        }
    }

    CRCByReceive = (uint16)pResultBuf[resultLen-3]*256+pResultBuf[resultLen-2];
    CRCByCal = calCRC(pResultBuf+1,resultLen-4);// ��ͷ����β��CRC��У��

    if (CRCByReceive==CRCByCal)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }      
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void writeCmd(uint8 first,uint16 insdata,uint8 num)//�����롢�����롢λ��
{
    vfCom.sendRawBuf[0] = first;
    vfCom.sendRawBuf[1] = insdata;
    if (num == 2)
    {
        if (vfCom.receiveBuf[1] == 0x19)//����ADֵ
        {
            vfCom.sendRawBuf[2] = currentAdOne; 
            vfCom.sendRawBuf[3] = currentAdTwo; 
    		vfCom.sendRawBuf[4] = 0;
        }
        else
        {
            vfCom.sendRawBuf[2] = 0;
            vfCom.sendRawBuf[3] = 0;
    		vfCom.sendRawBuf[4] = 0;
		}
		vfCom.sendPacketLen = 5;
    }
    else if (num == 1)
    {
        vfCom.sendRawBuf[2] = 0;
		vfCom.sendRawBuf[3] = 0;
        vfCom.sendPacketLen = 4;                        
    }
	else if (num == 0)
    {
        vfCom.sendRawBuf[2] = 0;
        vfCom.sendPacketLen = 3;                        
    }
    
    vfCom.sendPacketLen = vvvfComPacket(vfCom.sendRawBuf,
                         vfCom.sendBuf,vfCom.sendPacketLen);         
    VF_RE_TX;    
	vfCom.sendStatus = VF_COM_ST_TX; 
    TDR0 = vfCom.sendBuf[0];
    vfCom.sendIndex = 1;  
    vfCom.sendTimes = 1;   
}




void receiveData(void)
{
    uint8 RDR0temp;
    RDR0temp = RDR0;

	if ( vfCom.rxIng==TRUE ) // �Ѿ����յ���ͷ�����ݰ������С�
	{
		if( RDR0temp == 0xF4 )				//�յ���β
		{
			vfCom.receiveRawBuf[vfCom.rxIndex] = 0xF4;
			vfCom.rxIng = FALSE;
			vfCom.rxPacketLen++;								
			vfCom.newPackage = TRUE;
		}
		else                                //���ݽ�����
		{
		    vfCom.receiveRawBuf[vfCom.rxIndex] = RDR0temp;			
			vfCom.rxIndex++;
			vfCom.rxPacketLen++;		
			if( vfCom.rxPacketLen>19 )vfCom.rxIng = FALSE;	//���ݰ��ֽ�������
		}
	}		
	else if (RDR0temp==0xF6) //���յ���ͷ	
	{		
	    vfCom.receiveRawBuf[0] = RDR0temp;
		vfCom.rxIndex = 1;	
		vfCom.rxIng = TRUE;
		vfCom.rxPacketLen = 1; 
		vfCom.rxTime = 2; // ���ճ�ʱʱ��Ϊ0.1-0.2��     
	}	
}

uint8 currentAdOne;
uint8 currentAdTwo;

uint8 status = 0;
uint8 insCode = 0;
uint8 freqHig;
uint8 freqLow;

void analyzeData(void)
{
    if (vfCom.newPackage == TRUE)
    {
        if (vvvfComUnpacket(vfCom.receiveRawBuf,vfCom.receiveBuf,vfCom.rxPacketLen))
        {
            insCode = vfCom.receiveBuf[1];
            
            if (insCode==0x10) 
			{
				writeCmd(0xF1,0x10,2);
			}
            else if (insCode==0x11) // Ƶ��
            {
				writeCmd(0xF1,0x11,2);
            }
            else if (insCode==0x13) // ����
            {
				writeCmd(0xF1,0x13,2);
            }
			else if (insCode==0x18) // 
			{
				writeCmd(0xF1,0x18,2);
			}
			else if (insCode == 0x19) // ��������
            {
				writeCmd(0xF1,0x19,2);
            }
			else if (insCode==0x1A) // ���ش�����Ϣ
			{
				writeCmd(0xF1,0x1A,1);
			}
            else if (insCode==0x20) // ���ز�����
			{
				writeCmd(0xF1,0x20,1);
			}
			else if (insCode==0x28) // 
            {
				writeCmd(0xF1,0x28,1);
            }
			else if (insCode==0x90) // дƵ��
            {
				writeCmd(0xF2,0x90,0);
                if((vfCom.receiveBuf[2] == 0) & (vfCom.receiveBuf[3] == 0))
                {
                    freqHig = 0;
                    freqLow = 0;
                    status = SUSPEND;
                }
                else
                {
                    freqHig = vfCom.receiveBuf[2];
                    freqLow = vfCom.receiveBuf[3];
                }
            }
			else if (insCode==0x98) // 
            {
				writeCmd(0xF2,0x98,0);
				currentAdOne = vfCom.receiveBuf[2]; 
				currentAdTwo = vfCom.receiveBuf[3]; 
            }
			else if (insCode==0xA0) // 
            {
				writeCmd(0xF2,0xA0,1);
                
                if((vfCom.receiveBuf[2] & 0x80) == 0x80)
                    status = RUN;
                else
                    status = STOP;
            }
			else if (insCode==0xA8) // 
            {
				writeCmd(0xF2,0xA8,1);
            }
            else if (insCode==0x30) // 
            {
                writeNoHumanCmd(1);
            }
        }
		vfCom.newPackage = FALSE;
    }
}

void writeNoHumanCmd(uint8 num)
{
    vfCom.sendRawBuf[0] = 0xF1;
    vfCom.sendRawBuf[1] = 0x30;
    vfCom.sendRawBuf[2] = 0;
    vfCom.sendRawBuf[3] = num;
    vfCom.sendRawBuf[4] = 0;
    vfCom.sendPacketLen = 5;
    vfCom.sendPacketLen = vvvfComPacket(vfCom.sendRawBuf,
                            vfCom.sendBuf,vfCom.sendPacketLen);         
    VF_RE_TX;    
    vfCom.sendStatus = VF_COM_ST_TX; 
    TDR0 = vfCom.sendBuf[0];
    vfCom.sendIndex = 1;  
    vfCom.sendTimes = 1;
}
