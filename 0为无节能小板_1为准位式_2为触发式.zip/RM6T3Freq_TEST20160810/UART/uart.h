#ifndef _UART_H_  
#define _UART_H_  

extern uint8 status;
extern uint8 insCode;
extern uint8 freqHig;
extern uint8 freqLow;

extern uint8 currentAdOne;
extern uint8 currentAdTwo;

#define P_CTRL_TX		IO_PDR1.bit.P11	
#define D_CTRL_TX		IO_DDR1.bit.P11	
#define P_CTRL_RX		IO_PDR1.bit.P10	
#define D_CTRL_RX		IO_DDR1.bit.P10	

#define VF_RE_P			IO_PDR1.bit.P13	 
#define VF_RE_D			IO_DDR1.bit.P13 // DATA INPUT OR OUPUT PATH

#define VF_RE_RX     {VF_RE_P = 0;}
#define VF_RE_TX     {VF_RE_P = 1;}


#define VF_COM_ST_IDLE  0 // ���Ϳ���
#define VF_COM_ST_TX    1 // ������
#define VF_COM_ST_WAP   2 // �ȴ�Ӧ��




typedef struct __vfCom
{
    uint8 sendRawBuf[20];
    uint8 sendBuf[20];
    uint8 receiveRawBuf[20];
    uint8 receiveBuf[20];

    
    uint16 CRC;
		
	uint8 *pTXBuffer;
	
	uint8 rxIndex;
	uint8 rxIng;// ������
	uint8 newPackage;
	uint8 rxPacketLen;
	uint8 rxTime;


	uint8 sendStatus;	
	uint8 sendPacketLen;
	uint8 sendIndex;
	uint8 sendTimes;

	uint8 packetTime;	
}VF_COM;

typedef struct __vfComTest
{
    uint16 dataTempRead;
    uint16 dataTempWrite;    
    uint8  dataItem;
}VF_COM_TEST;

extern VF_COM vfCom;
extern VF_COM_TEST vfComTest;

void converter_UART_SIO_Init(void);
void VfCom_Init(void);
void receiveData(void);

uint16 calCRC(uint8 *pSrcBuf,uint8 len);
uint8 vvvfComPacket(uint8 *pSrcBuf,uint8 *pResultBuf,uint8 len);
uint8 vvvfComUnpacket(uint8 *pSrcBuf,uint8 *pResultBuf,uint8 len);


#endif
