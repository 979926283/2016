#include "../INC/Untype_def.h"
#ifndef _ENER_SAVING_H_
#define _ENER_SAVING_H_

#define P_POW_Ctrl   PDRC_PC2
#define D_POW_Ctrl   DDRC_PC2


#define P_MODE_CS   PDRE_PE4 //MODE
#define D_MODE_CS   DDRE_PE4


#define P_WK   PDR0_P04
#define D_WK   DDR0_P04
#define P_SB   PDR0_P03
#define D_SB   DDR0_P03

typedef struct
{
    INT8U timeCnt;
}ENER_SAVING;

extern ENER_SAVING ener_sav;


extern void EnerSaving_Init(void);
extern void TriggerStateCtrl(void);
extern void AccuratePosition(void);
extern void EnerSaving_ModeSelect(void);


#endif
