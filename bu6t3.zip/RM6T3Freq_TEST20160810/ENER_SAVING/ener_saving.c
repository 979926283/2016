#include "../SRC/MB95770.h"
#include "../INC/Untype_def.h"
#include "../DISPLAY/display.h"
#include "ener_saving.h"

ENER_SAVING ener_sav;
Bit_FLAGSTR bitFlag;

void EnerSaving_Init(void)
{
    D_WK = IO_INPUT;
    D_SB = IO_INPUT;

    D_MODE_CS = IO_INPUT;
    
    ener_sav.timeCnt = 0;
}

/**************����ʽ*******************/
void TriggerStateCtrl(void)
{
    if(P_WK == P_SB)
    {
    }
    else if(!P_WK)
    {
        P_POW_Ctrl = IO_OUTPUT;
        closeDisFlag = 0;
    }
    else if(!P_SB)
    {
        P_POW_Ctrl = IO_INPUT;
        closeDisFlag = 1;
    }
}

/**************׼λʽ*******************/
void AccuratePosition(void)
{
    if(P_WK==1)
    {
        P_POW_Ctrl = IO_INPUT;
        closeDisFlag = 1;
    }
    else if(P_WK==0)
    {
        P_POW_Ctrl = IO_OUTPUT;
        closeDisFlag = 0;
    }
}

/*******������ʱ5���л�״̬��ִ��*******/
void EnerSaving_ModeSelect(void)
{
    if(enerSav_keyStatus == 0)
    {
        if(ener_sav.timeCnt < 50)
        {
            EnerSav_DisBuf(0);
        }
        if(ener_sav.timeCnt >= 50)
        {
            AccuratePosition();//׼λʽ
        }
    }
    else
    {
        if(ener_sav.timeCnt < 50)
        {
            EnerSav_DisBuf(1);
        }
        if(ener_sav.timeCnt >= 50)
        {
            TriggerStateCtrl();//����ʽ
        }
    }
}



