#ifndef _TIMER0_H  //��ֹ�ظ�����
#define _TIMER0_H  //��ֹ�ظ�����

#define    P_BUZZ_CTL  PDRE_PE1


extern void Timr0_Init(void);
extern void Init_TIMER1(void);
extern void Time0Val_Init(void);

typedef struct
{
    INT8U Cnt_500us;
    INT8U Cnt_1ms;
    INT8U Cnt_2ms;
    INT8U Cnt_10ms;
    INT8U Cnt_20ms;
    INT8U Cnt_25ms;
    INT8U Cnt_30ms;
    INT8U Cnt_50ms;
    INT8U Cnt_100ms;
    INT8U Cnt_300ms;
    INT8U Cnt_500ms;
}TIMER_USRRAM;

extern TIMER_USRRAM g_tTime;





#endif
