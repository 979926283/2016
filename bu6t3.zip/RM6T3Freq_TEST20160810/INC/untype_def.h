#ifndef _UNTYPE_DEF_H_
#define _UNTYPE_DEF_H_


typedef unsigned char   uint8;
typedef unsigned int    uint16;
typedef unsigned long   uint32;
typedef unsigned char	INT8U;  
typedef unsigned int	INT16U; 
typedef unsigned long	INT32U; 


/*----------------------------------------------------*/
#define     BIT0    0X01
#define     BIT1    0X02
#define     BIT2    0X04
#define     BIT3    0X08
#define     BIT4    0X10
#define     BIT5    0X20
#define     BIT6    0X40
#define     BIT7    0X80

#define     NUM0    0X01
#define     NUM1    0X02
#define     NUM2    0X03
#define     NUM3    0X04
#define     NUM4    0X05
#define     NUM5    0X06
#define     NUM6    0X07
#define     NUM7    0X08

typedef unsigned char	tByte;

#define IO_OUTPUT       0x01
#define IO_INPUT        0X00
#define	IO_BIT_HI		0X01
#define	IO_BIT_LOW		0X00
#define	TRUE			0X01
#define	FALSE			0X00
#define	ON				0x01
#define	OFF				0x00
#define	_ON				0x01
#define	_OFF			0x00
#define	STOP			0x00
#define	RUN				0x01
#define	SUSPEND			0x02
#define HIG             0x02
#define LOW             0x00
#define ESP             0x03 
#define ENABLE          0x01
#define DISABLE         0x00
#define NULL            0x00



typedef union
{                    //  Flag Data/Direction Registers 
    tByte byte;
    struct
    {
        tByte F00 :1;
        tByte F01 :1;
        tByte F02 :1;
        tByte F03 :1;
        tByte F04 :1;
        tByte F05 :1;
        tByte F06 :1;
        tByte F07 :1;
    }bit;
}Bit_FLAGSTR;

extern Bit_FLAGSTR bitFlag1;
extern Bit_FLAGSTR bitFlag2;

#define TimeCnt250Us_bit    bitFlag1.bit.F00
#define TimeCnt500Us_bit    bitFlag1.bit.F01
#define TimeCnt1Ms_bit      bitFlag1.bit.F02
#define TimeCnt10Ms_bit     bitFlag1.bit.F03
#define TimeCnt25Ms_bit     bitFlag1.bit.F04
#define TimeCnt50Ms_bit     bitFlag1.bit.F05
#define TimeCnt100Ms_bit    bitFlag1.bit.F06
#define TimeCnt300Ms_bit    bitFlag1.bit.F07

#define enerSav_keyStatus   bitFlag2.bit.F00
#define ESPbuzzCnt          bitFlag2.bit.F01
#define kFlag               bitFlag2.bit.F02
#define closeDisFlag        bitFlag2.bit.F03
#define Cnt5sFlag           bitFlag2.bit.F04









#endif
