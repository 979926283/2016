#ifndef _BUZZ_H_
#define _BUZZ_H_

//���Q��
#define P_BUZZER_OUT	IO_PDRE.bit.PE1// BUZZER
#define D_BUZZER_OUT	IO_DDRE.bit.PE1	// DATA INPUT OR OUPUT PATH

typedef struct 
{
	uint8 BuzzerCnt;    //�O�����Q��푵ĴΔ�
	uint8 BuzzerTime;
	uint8 SetBuzzerTime; //�O�����Q���r�g
    uint8 BeepOn_bit  :1;
	uint8 Buzzer10ms_bit :1;

}BUZZER_RAM;
extern BUZZER_RAM buzzer_ram;


extern void Buzzer_Process(void);	// ���Q�� Program
extern void Buzzer_KeyBI(void);
extern void Buzzer_Bz(void);
extern void Buzzer_3Bz(void);
extern void Buzzer_Bz_Bz_Bz(void);
extern void Buzzer_Bz_Long(void);

#endif
