#include "mb95560.h"
#include "MB95F264_UART.h"

VF_COM vfCom;

void delay_time(unchar data)
{
	unchar i;
	for(i = 0;i<data;i++){
		WDTC = 0x35;
	    __wait_nop();
	    __wait_nop();
	    __wait_nop();
	}
}

void initVfCom(void)
{
    vfCom.newPackage = FALSE;
    vfCom.rxTime = 0;
    vfCom.packetTime = 0;    
}
/****************************************************************************/
void Init_UART(void)
{
	AIDRL   = 0xFF; 

	D_CTRL_TX = 1;
	D_CTRL_RX = 0;
	VF_RE_D = 1;
	P_CTRL_TX = 0;
	P_CTRL_RX = 0;
	VF_RE_P = 0;

	SCR = 0X12;
	SMR = 0x05;
	SSR=0x02;

	BGR1 = 0x00;
	BGR0 = 0x19;//MB95264  0x33;
}

__interrupt void Inter_uart_Rx(void)
{	
	if(SSR_RDRF)
	{
		receiveData();
	}
}
/*
__interrupt Inter_uart_Tx(void)
{
    if(SSR_TDRE)
    {
        RDR_TDR = 0X02;
    }
}
*/
/*----------------------------------------------------------------*/
uint16 calCRC(uint8 *pSrcBuf,uint8 len)
{
    uint8 i;
    uint16 reg_crc = 0xffff;
    
    while(len--)
    {
        reg_crc^= *pSrcBuf++;        
        for(i = 0;i < 8;i++)
        {
            if(reg_crc & 0x01) reg_crc = (reg_crc>>1)^0xA001;            
            else reg_crc = reg_crc>>1;            
        }
    }

    return reg_crc;
}

/*------------------------------------------------------------------
�Խ��յ������ݽ��зֽ�,�鿴�����Ƿ���ȷ
-------------------------------------------------------------------*/
uint8 vvvfComUnpacket(uint8 *pSrcBuf,uint8 *pResultBuf,uint8 len)
{
    uint8  resultLen;
    uint8  *pResultBufTemp;
    uint16 CRCByReceive;
    uint16 CRCByCal;

    pResultBufTemp = pResultBuf;
    pResultBufTemp[0] = pSrcBuf[0];
    pSrcBuf++;
    pResultBufTemp++;
    len--;// ȥ����ͷ��һ���ֽں󣬶����ݽ��в�֡�
    resultLen = 1;
    while(len)
    {
        if ( (*pSrcBuf) == 0xF7 )
        {
            pSrcBuf++;
            *pResultBufTemp = 0xF0 + (*pSrcBuf);
            pResultBufTemp++;
            pSrcBuf++;  
            resultLen++;
            len -= 2;
        }
        else
        {
            *pResultBufTemp = *pSrcBuf;
            pResultBufTemp++;
            pSrcBuf++;  
            
            resultLen++;
            len--;
        }
    }

    CRCByReceive = (uint16)pResultBuf[resultLen-3]*256+pResultBuf[resultLen-2];
    CRCByCal = calCRC(pResultBuf+1,resultLen-4);// ��ͷ����β��CRC��У��

    if (CRCByReceive==CRCByCal)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }      
}


void receiveData(void)
{
    uint8 RDR0temp;
    RDR0temp = RDR_TDR;
   	if ( vfCom.rxIng==TRUE ) // �Ѿ����յ���ͷ�����ݰ������С�
	{
		if( RDR0temp == 0xF4 )				//�յ���β
		{
			vfCom.receiveRawBuf[vfCom.rxIndex] = 0xF4;
			vfCom.rxIng = FALSE;
			vfCom.rxPacketLen++;								
			vfCom.newPackage = TRUE;
		}
		else                                //���ݽ�����
		{
		    vfCom.receiveRawBuf[vfCom.rxIndex] = RDR0temp;			
			vfCom.rxIndex++;
			vfCom.rxPacketLen++;		
			if( vfCom.rxPacketLen>19 )vfCom.rxIng = FALSE;	//���ݰ��ֽ�������
		}
	}		
	else if (RDR0temp==0xF6) //���յ���ͷ	
	{		
	    vfCom.receiveRawBuf[0] = RDR0temp;
		vfCom.rxIndex = 1;	
		vfCom.rxIng = TRUE;
		vfCom.rxPacketLen = 1; 
		vfCom.rxTime = 2; // ���ճ�ʱʱ��Ϊ0.1-0.2��     
	}	
}

uint16 insCode;
uint8 tmp_i = 0;

void analyzeData(void)
{
    if (vfCom.newPackage == TRUE)
    {
        if (vvvfComUnpacket(vfCom.receiveRawBuf,vfCom.receiveBuf,vfCom.rxPacketLen))
        {
            insCode = vfCom.receiveBuf[1];
            
            if(insCode == 0x90)  //дƵ��
            {
                if((vfCom.receiveBuf[2] != 0) & (vfCom.receiveBuf[3] != 0))
                {
                    vfCom.RLFlag = 1;////

                    tmp_i = 0;
                }
                else if((vfCom.receiveBuf[2] == 0) & (vfCom.receiveBuf[3] == 0))
                {
                    vfCom.RLFlag = 0;////
                }
            }
            
            else if(insCode == 0xA0)  //д��������
            {
                if(vfCom.receiveBuf[2] == 0x80)
                {
                    vfCom.RLFlag = 1;////

                    tmp_i = 0;
                }
                else if(vfCom.receiveBuf[2] == 0) //��2��ֹͣkeyһ�����ü̵����Ͽ�
                {
                    tmp_i++;
                    if(tmp_i > 3)
                    {
                        vfCom.RLFlag = 0;////
                    }
                }
            }
        }
		vfCom.newPackage = FALSE;
    }
}


