#ifndef _MB95F264_UART_H  //��ֹ�ظ�����
#define _MB95F264_UART_H  //��ֹ�ظ�����
#define		UART_CMD_OK		0xB0
#define		UART_CMD_ERR		0xD0
#define		UART_CMD_AD		0xD1

#define P_CTRL_TX		IO_PDR0.bit.P03	
#define D_CTRL_TX		IO_DDR0.bit.P03	
#define P_CTRL_RX		IO_PDR0.bit.P04	
#define D_CTRL_RX		IO_DDR0.bit.P04

#define VF_RE_P			IO_PDR0.bit.P07 
#define VF_RE_D			IO_DDR0.bit.P07

//#define RL_D			IO_DDR0.bit.P01
//#define RL				IO_PDR0.bit.P0



#define TRUE 1
#define FALSE 0


#define unchar unsigned char
typedef unsigned char   uint8;
typedef unsigned int    uint16;
typedef unsigned long   uint32;
//typedef unsigned char	INT8U;  
//typedef unsigned int	INT16U; 
//typedef unsigned long	INT32U;





typedef struct __vfCom
{
    uint8 sendRawBuf[20];
    uint8 sendBuf[20];
    uint8 receiveRawBuf[20];
    uint8 receiveBuf[20];

    
    uint16 CRC;
		
	uint8 *pTXBuffer;
	
	uint8 rxIndex;
	uint8 rxIng;// ������
	uint8 newPackage;
	uint8 rxPacketLen;
	uint8 rxTime;


	uint8 sendStatus;	
	uint8 sendPacketLen;
	uint8 sendIndex;
	uint8 sendTimes;

	uint8 packetTime;

    uint8 RLFlag;
    uint8 statusFlag;
}VF_COM;

extern VF_COM vfCom;

extern void delay_time(unchar data);
extern void analyzeData(void);
extern void receiveData(void);
uint16 calCRC(uint8 *pSrcBuf,uint8 len);
uint8 vvvfComUnpacket(uint8 *pSrcBuf,uint8 *pResultBuf,uint8 len);



extern void Init_UART(void);

#endif
