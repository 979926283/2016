#include "MB95F264_UART.h"

#include "mb95560.h"

#include "timer.h"


void Init_TIMER0(void)
{   
    RL_D = 1;
	RL = 0;

    T00CR0 = 0xB1;
	
	T00CR1 = 0x20;
	
	TMCR0  = 0x20;
	
	T00DR  = 250;	
	
	T00CR1_STA =1;

}
/*--------------------------------------------------------------------------- 
//4ms�ж�һ��...
-----------------------------------------------------------------------------*/
//uint16 onesecCnt = 0;
//uint8 onesecFlag = 0;

uint8 Cnt_50ms = 6;
uint8 tmp_w = 0;

__interrupt void Inter_Timer0(void)
{
    Cnt_50ms--;
    if(Cnt_50ms == 0)
    {
        Cnt_50ms = 6;

        if(vfCom.RLFlag == 1)
        {
            RL = 1;

            tmp_w = 0;
        }
        else if(vfCom.RLFlag == 0)
        {
            tmp_w++;
            if(tmp_w > 50)
            {
                tmp_w = 0;
                RL = 0;
            }
        }
        
    }

    
    
	WDTC = 0x35;
	T00CR1_IF = 0;
}
